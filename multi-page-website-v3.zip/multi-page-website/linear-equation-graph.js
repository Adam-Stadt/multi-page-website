// Canvas setup
let cnv = document.getElementById("myCanvas");
let ctx = cnv.getContext("2d");
cnv.width = 600;
cnv.height = 400;

// element variables
let slopeIn = document.getElementById("new-eq-slope");
let yInterceptIn = document.getElementById("new-eq-y");
let colorIn = document.getElementById("new-eq-color");
let addEqBtn = document.getElementById("add-eq");
let clearBtn = document.getElementById("clear-btn");

// global variables
let mouseX = 0;
let mouseY = 0;

// event listeners
addEqBtn.addEventListener("click", addEquation);
clearBtn.addEventListener("click", removeEquations);

document.addEventListener("mousemove", followMouse);

function addEquation() {
    drawLine(+slopeIn.value * 25, +yInterceptIn.value * 5, colorIn.value);
}

function removeEquations() {
    drawPlane();
    drawTicks();
    drawMouseCoords();
}

function followMouse() {
    let cnvRect = cnv.getBoundingClientRect(); 
    mouseX = event.clientX - cnvRect.left;
    mouseY = event.clientY - cnvRect.top;
    // I don't want the coordinate numbers to reflect points outside the graph, so I'll make the numbers change only if the mouse is on the canvas. 
    if (-60 + mouseX / 5 > 60) {
        mouseX = 600;
    }
    if (-60 + mouseX / 5 < -60) {
        mouseX = 0;
    }
    if (40 - mouseY / 5 > 40) {
        mouseY = 0;
    }
    if (40 - mouseY / 5 < -40) {
        mouseY = 400;
    }
    drawMouseCoords();
}

// draw the base graph
function drawPlane() {
    ctx.fillStyle = "white";
    ctx.fillRect(0, 0, 600, 400);
    ctx.strokeStyle = "black";
    ctx.lineWidth = 1;
    // draw both axes
    ctx.beginPath();
    ctx.moveTo(300, 0);
    ctx.lineTo(300, 400);
    ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(0, 200);
    ctx.lineTo(600, 200);
    ctx.stroke();
    ctx.font = "24px Arial";
    ctx.fillStyle = "black";
    // label axes
    ctx.fillText("x", 583, 193);
    ctx.fillText("y", 305, 20);
}

function drawMouseCoords() {
    // make a little box for the numbers
    ctx.fillStyle = "white";
    ctx.fillRect(525, 375, 75, 25);
    ctx.strokeStyle = "black";
    ctx.strokeRect(525, 375, 75, 25);
    ctx.font = "16px Arial";
    // I don't want the text to change length a lot, because it looks strange, so I'll put all these down separately.
    ctx.strokeText(Math.round(-60 + mouseX / 5), 530, 394);
    ctx.strokeText(",", 555, 394);
    ctx.strokeText(Math.round(40 - mouseY / 5), 565, 394)
}

function drawTicks() {
    ctx.font = "12px Arial";
    ctx.fillStyle = "black";
    for (let xticks = 0; xticks <= 10; xticks++) {
        // this skips the middle one
        if (xticks !== 5) {
            // draw a tick mark
            ctx.beginPath();
            ctx.moveTo(50 * (xticks + 1), 200);
            ctx.lineTo(50 * (xticks + 1), 190);
            ctx.stroke();
            // draw the number for the tick mark
            ctx.fillText((-5 + xticks) * 10, 50 * (xticks + 1) + 5, 195);
        }
    }
    for (let yticks = 0; yticks <= 6; yticks++) {
        // this skips the middle one
        if (yticks !== 3) {
            // draw a tick mark
            ctx.beginPath();
            ctx.moveTo(300, 50 * (yticks + 1));
            ctx.lineTo(310, 50 * (yticks + 1));
            ctx.stroke();
            // draw the number for the tick mark
            ctx.fillText((3 - yticks) * 10, 305, 50 * (yticks + 1) - 5);
        }
    }
    ctx.fillText("0", 305, 195);
}

function drawLine(slope, yInt, color) {
    ctx.strokeStyle = color;
    ctx.beginPath();
    // this is like the 'offset' for the slope
    let xStart = -3;
    ctx.moveTo(0, 0 - (slope * xStart + yInt - 200));
    ctx.lineTo(600, 0 - (slope * (0 - xStart) + yInt - 200));
    ctx.stroke();
    // i don't want this going over my mouse coords, so i'll redraw those
    drawMouseCoords();
}

drawPlane();
drawTicks();
drawMouseCoords();