// Element Variables
let qOneIn = document.getElementById("quiz1in");
let qTwoIn = document.getElementById("quiz2in");
let qThreeIn = document.getElementById("quiz3in");
let qFourIn = document.getElementById("quiz4in");
let submitEl = document.getElementById("submit");
let numeratorEl = document.getElementById("numerator");
let percentageEl = document.getElementById("percentage");
let feedbackEl = document.getElementById("feedback");
let qOneImg = document.getElementById("img-q-1");
let qTwoImg = document.getElementById("img-q-2");
let qThreeImg = document.getElementById("img-q-3");
let qFourImg = document.getElementById("img-q-4");

// Event Listener
submitEl.addEventListener("click", checkAnswers);

function checkAnswers() {
    // Input
    let oneAnswer = +qOneIn.value;
    let twoAnswer = +qTwoIn.value;
    let threeAnswer = qThreeIn.value.toLowerCase();
    let fourAnswer = +qFourIn.value;

    // Most of the answers are numbers, so I don't have to worry about case. I did include one non-numerical answer to show that I know how to do case-insensitive, and also for the multiple-answer requirement

    let oneCorrect;
    let twoCorrect;
    let threeCorrect;
    let fourCorrect;
    let numCorrect = 0;

    // Process
    if (oneAnswer === 18) {
        oneCorrect = true;
    } else {
        oneCorrect = false;
    }
    
    if (twoAnswer === 18) {
        twoCorrect = true;
    } else {
        twoCorrect = false;
    }

    if (threeAnswer === "radius" || threeAnswer === "r") {
        threeCorrect = true;
    } else {
        threeCorrect = false;
    }

    if (fourAnswer === 36) {
        fourCorrect = true;
    } else {
        fourCorrect = false;
    }

    // Output:
    // This first section shows the user which answers they got right, and which they got wrong. It also counts the number of answers the user has gotten right.
    if (oneCorrect) {
        qOneIn.classList.remove("incorrect");
        qOneIn.classList.add("correct");
        qOneImg.src = "img/checkmark.png"
        numCorrect++;
    } else {
        qOneIn.classList.remove("correct");
        qOneIn.classList.add("incorrect");
        qOneImg.src = "img/x-mark.png"
    }

    if (twoCorrect) {
        qTwoIn.classList.remove("incorrect");
        qTwoIn.classList.add("correct");
        qTwoImg.src = "img/checkmark.png"
        numCorrect++;
    } else {
        qTwoIn.classList.remove("correct");
        qTwoIn.classList.add("incorrect");
        qTwoImg.src = "img/x-mark.png"
    }

    if (threeCorrect) {
        qThreeIn.classList.remove("incorrect");
        qThreeIn.classList.add("correct");
        qThreeImg.src = "img/checkmark.png"
        numCorrect++;
    } else {
        qThreeIn.classList.remove("correct");
        qThreeIn.classList.add("incorrect");
        qThreeImg.src = "img/x-mark.png"
    }

    if (fourCorrect) {
        qFourIn.classList.remove("incorrect");
        qFourIn.classList.add("correct");
        qFourImg.src = "img/checkmark.png"
        numCorrect++;
    } else {
        qFourIn.classList.remove("correct");
        qFourIn.classList.add("incorrect");
        qFourImg.src = "img/x-mark.png"
    }

    // These two lines show the user their total score and percentage
    numeratorEl.innerHTML = numCorrect;
    percentageEl.innerHTML = numCorrect * 25;

    // This if statement outputs a motivational message dependant on score
    if (numCorrect === 0 || numCorrect === 1) {
        feedbackEl.innerHTML = "You can do better!"
    } else if (numCorrect === 2 || numCorrect === 3) {
        feedbackEl.innerHTML = "That wasn't bad, but there's still room for improvement!"
    } else {
        feedbackEl.innerHTML = "Congratulations! You know your stuff!"
    }
}