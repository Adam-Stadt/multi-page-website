// Elemental Variables
let resultEl = document.getElementById("result");
let orderEl = document.getElementById("order");
let minEl = document.getElementById("min-factor");
let maxEl = document.getElementById("max-factor");
let multiRootEl = document.getElementById("doubleroot");
let generateBtn = document.getElementById("generate-btn");
let revealBtn = document.getElementById("answer-btn");
let answerEl = document.getElementById("answer");

// factors array
let factors = [-1, 0];
let multiplyingFactors = [];
let factorsNeeded = 1;
let needMoreFactors = true;
let thisFactor = 0;
let productsFound = [];
let product = 1;
let coeff;
let finalSum = 0;

// event listener
generateBtn.addEventListener("click", generatePolynomial);
revealBtn.addEventListener("click", showAnswer);

function showAnswer() {
    if (answerEl.innerHTML !== "What were you expecting?") {
        answerEl.innerHTML = "Factors are: ___";
        factors.forEach(formatAnswer);
    }
}

function formatAnswer(factor) {
    if (answerEl.innerHTML === "Factors are: ___") {
        answerEl.innerHTML = "Factors are: " + factor;
    } else {
        answerEl.innerHTML += ", " + factor;
    }
}

function generatePolynomial() {
    answerEl.innerHTML = "Factors are: ___";
    factors = [];
    if (+orderEl.value > 20) {
        orderEl.value = 20;
    } else if (+orderEl.value < 1) {
        // just figured I'd put this in as a joke
        if (+orderEl.value === 0) {
            resultEl.innerHTML = "0 = 0";
            answerEl.innerHTML = "What were you expecting?";
            return;
        }
        orderEl.value = 1;
    }
    if (+minEl.value > +maxEl.value) {
        // this ensures that i have a valid range to choose from
        if (multiRootEl.checked) {
            maxEl.value = minEl.value;
        } else {
            maxEl.value = +minEl.value + (+orderEl.value);
        }
    }
    for (let num = 0; num < +orderEl.value; num++) {
        let newFactor = +minEl.value + Math.random() * (+maxEl.value - +minEl.value);
        newFactor = Math.round(newFactor);
        if (multiRootEl.checked || !factors.includes(newFactor)) {
            factors.push(newFactor);
        } else {
            num--;
        }
    }
    assemblePolynomial();
}

function assemblePolynomial() {
    let resultString = "";
    for (let index = factors.length; index >= 0; index--) {
        if (index !== factors.length) {
            iterationSetup(factors.length - index);
            coeff = finalSum;
        } else {
            coeff = 1;
        }
        if (coeff > 0 && !(index === factors.length)) {
            resultString += " + ";
        } else if (coeff < 0 && !(index === factors.length)) {
            resultString += " - ";
        }
        if (coeff !== 0) {
            if (index === 0) {
                resultString += Math.abs(coeff);
            } else {
                if (Math.abs(coeff) === 1) {
                    resultString += "x";
                } else {
                    resultString += Math.abs(coeff) + "x";
                }
                if (index !== 1) {
                    resultString += "^" + index;
                }
            }
        }
    }
    resultEl.innerHTML = resultString + " = 0";
}

function iterationSetup(needed) {
    multiplyingFactors = [];
    productsFound = [];
    finalSum = 0;
    factorsNeeded = needed;
    thisFactor = 0;
    if (needed === 1) {
        factors.forEach(sumArray);
        finalSum = 0 - finalSum;
    } else {
        iterateMultiply();
    }
}

function multiplyArray(factor) {
    // i have to invert this ofc
    product = product * (0 - factors[factor]);
}

function sumArray(num) {
    finalSum += num;
}

function iterateMultiply() {
    let multiplicationArray = [];
    needMoreFactors = true;
    finalSum = 0;
    // add things to multiplicationArray
    for (let num = 0; num < factorsNeeded; num++) {
        multiplicationArray[num] = num;
    }
    // now i should have "1 2 3 etc." this is what i will start with.
    product = 1;
    multiplicationArray.forEach(multiplyArray);
    for (let productArray = [product]; needMoreFactors; productArray.push(product)) {
        product = 1;
        // now i update multiplicationArray,
        changeItem(multiplicationArray, multiplicationArray.length - 1, factors.length);
        // and i find the new product
        if (!needMoreFactors) {
            productArray.forEach(sumArray);
            break;
        }
        multiplicationArray.forEach(multiplyArray);
    }
}

function changeItem(arr, index, max) {
    if (arr[index] + 1 < max) {
        arr[index] += 1;
    } else {
        for (let recur = 1; index - recur >= 0; recur++) {
            if (arr[index - recur] + recur < max - 1) {
                arr[index - recur] += 1;
                while (recur !== 0) {
                    recur--;
                    arr[index - recur] = arr[index - recur - 1] + 1;
                }
                break;
            }
            if (index - recur === 0 && factorsNeeded + arr[index - recur] >= max) {
                needMoreFactors = false;
                break;
            }
        }
    }
}

// honestly can't believe this worked
// some testingue :
// (x-1)(x-2)(x-4) -> x^3 -7x^2 +14x -8