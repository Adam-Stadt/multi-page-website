// Element Variables
let qOneInA = document.getElementById("quiz1inA");
let qOneInB = document.getElementById("quiz1inB");
let qTwoInA = document.getElementById("quiz2inA");
let qTwoInB = document.getElementById("quiz2inB");
let qThreeInA = document.getElementById("quiz3inA");
let qThreeInB = document.getElementById("quiz3inB");
let qThreeInC = document.getElementById("quiz3inC");
let qThreeInD = document.getElementById("quiz3inD");
let qFourInA = document.getElementById("quiz4inA");
let qFourInB = document.getElementById("quiz4inB");
let qFourInC = document.getElementById("quiz4inC");
let qFourInD = document.getElementById("quiz4inD");
let submitEl = document.getElementById("submit");
let numeratorEl = document.getElementById("numerator");
let percentageEl = document.getElementById("percentage");
let feedbackEl = document.getElementById("feedback");
let qOneImg = document.getElementById("img-q-1");
let qTwoImg = document.getElementById("img-q-2");
let qThreeImg = document.getElementById("img-q-3");
let qFourImg = document.getElementById("img-q-4");

// Sets of Inputs
let qOneInputs = [qOneInA, qOneInB];
let qTwoInputs = [qTwoInA, qTwoInB];
let qThreeInputs = [qThreeInA, qThreeInB, qThreeInC, qThreeInD];
let qFourInputs = [qFourInA, qFourInB, qFourInC, qFourInD];
let AInputs = [qOneInA, qTwoInA, qThreeInA, qFourInA];
let BInputs = [qOneInB, qTwoInB, qThreeInB, qFourInB];
let CInputs = [qThreeInC, qFourInC];
let DInputs = [qThreeInD, qFourInD];

// Event Listener
submitEl.addEventListener("click", checkAnswers);

// this stuff isn't as efficient as possible, but it works for all cases with very small adjustments, which is what I need b/c I'm making lots of these
qOneInputs.forEach(inputEventListen);
qTwoInputs.forEach(inputEventListen);
qThreeInputs.forEach(inputEventListen);
qFourInputs.forEach(inputEventListen);

function inputEventListen(element) {
    if (AInputs.includes(element)) {
        element.addEventListener("change", keepA);
    } else if (BInputs.includes(element)) {
        element.addEventListener("change", keepB);
    } else if (CInputs.includes(element)) {
        element.addEventListener("change", keepC);
    } else {
        element.addEventListener("change", keepD);
    }
}

function keepA() {
    changeExcept("a");
}

function keepB() {
    changeExcept("b");
}

function keepC() {
    changeExcept("c");
}

function keepD() {
    changeExcept("d");
}

function changeExcept(keep) {
    let duplicateArray = findDuplicate();
    if (duplicateArray === "none") {
        return;
    }
    if (keep !== "a") {
        duplicateArray[0].checked = false;
    }
    if (keep !== "b") {
        duplicateArray[1].checked = false;
    }
    if (keep !== "c") {
        duplicateArray[2].checked = false;
    }
    if (keep !== "d") {
        duplicateArray[3].checked = false;
    }
}

function findDuplicate() {
    let testArray = qOneInputs.filter(isChecked);
    if (testArray.length > 1) {
        console.log(1);
        return qOneInputs;
    }
    testArray = qTwoInputs.filter(isChecked);
    if (testArray.length > 1) {
        console.log(2);
        return qTwoInputs;
    }
    testArray = qThreeInputs.filter(isChecked);
    if (testArray.length > 1) {
        console.log(3);
        return qThreeInputs;
    }
    testArray = qFourInputs.filter(isChecked);
    if (testArray.length > 1) {
        console.log(4);
        return qFourInputs;
    }
    return "none";
}

function isChecked(input) {
    return input.checked;
}

function checkAnswers() {
    // Input
    let oneAnswer = qOneInputs.findIndex(isChecked);
    let twoAnswer = qTwoInputs.findIndex(isChecked);
    let threeAnswer = qThreeInputs.findIndex(isChecked);
    let fourAnswer = qFourInputs.findIndex(isChecked);

    let oneCorrect;
    let twoCorrect;
    let threeCorrect;
    let fourCorrect;
    let numCorrect = 0;

    // Process
    if (oneAnswer === 1) {
        oneCorrect = true;
    } else {
        oneCorrect = false;
    }
    
    if (twoAnswer === 0) {
        twoCorrect = true;
    } else {
        twoCorrect = false;
    }

    if (threeAnswer === 2) {
        threeCorrect = true;
    } else {
        threeCorrect = false;
    }

    if (fourAnswer === 0) {
        fourCorrect = true;
    } else {
        fourCorrect = false;
    }

    // Output:
    if (oneCorrect) {
        qOneImg.src = "img/checkmark.png"
        numCorrect++;
    } else {
        qOneImg.src = "img/x-mark.png"
    }

    if (twoCorrect) {
        qTwoImg.src = "img/checkmark.png"
        numCorrect++;
    } else {
        qTwoImg.src = "img/x-mark.png"
    }

    if (threeCorrect) {
        qThreeImg.src = "img/checkmark.png"
        numCorrect++;
    } else {
        qThreeImg.src = "img/x-mark.png"
    }

    if (fourCorrect) {
        qFourImg.src = "img/checkmark.png"
        numCorrect++;
    } else {
        qFourImg.src = "img/x-mark.png"
    }

    // These two lines show the user their total score and percentage
    numeratorEl.innerHTML = numCorrect;
    percentageEl.innerHTML = numCorrect * 25;

    // This if statement outputs a motivational message dependant on score
    if (numCorrect === 0 || numCorrect === 1) {
        feedbackEl.innerHTML = "You can do better!"
    } else if (numCorrect === 2 || numCorrect === 3) {
        feedbackEl.innerHTML = "That wasn't bad, but there's still room for improvement!"
    } else {
        feedbackEl.innerHTML = "Congratulations! You know your stuff!"
    }
}