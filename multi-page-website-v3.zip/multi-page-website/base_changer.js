// Elemental Variables
let inputNumEl = document.getElementById("input-num");
let inputBaseEl = document.getElementById("input-base");
let targetBaseEl = document.getElementById("target-base");
let resultNumInEl = document.getElementById("start-num");
let resultBaseInEl = document.getElementById("start-base");
let resultNumOutEl = document.getElementById("end-num");
let resultBaseOutEl = document.getElementById("end-base");
let btnEl = document.getElementById("change-button");

// globular variables 
// all this does is determine the order of digits
let numOrder = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z'];

// t h e y   a r e   l i s t e n i n g (event listeners)
btnEl.addEventListener("click", baseChange);

function baseChange() {
    // i don't want a number for the first one, as it may contain letters
    let startNum = inputNumEl.value.toLowerCase();
    let startBase = +inputBaseEl.value;
    let endBase = +targetBaseEl.value;
    let baseTenSum = 0;
    let resultAsArr = [];
    // make sure all the inputs are acceptable:
    if (endBase <= 1) {
        endBase = 2;
    } else if (endBase > 36) {
        endBase = 36;
        targetBaseEl.value = 36;
    }
    resultNumInEl.innerHTML = startNum;
    if (startNum.charAt(0) === "-") {
        // this checks to see if it's negative; I can't use '< 0' here because it may include letters
        startNum = startNum.substr(1, startNum.length - 1);
    }
    resultBaseInEl.innerHTML = startBase;
    resultBaseOutEl.innerHTML = endBase;
    // first, I'll convert the input to base 10:
    for (let charIndex = 0; charIndex < startNum.length; charIndex++) {
        // arrIndex is the 'value' of the currently selected character
        let arrIndex = numOrder.indexOf(startNum.charAt(charIndex));
        baseTenSum += arrIndex * (startBase ** (startNum.length - 1 - charIndex));
    } 
    // now, i just need to change it to the new base!
    let counter = 0;
    for (let power = findMaxPower(endBase, baseTenSum); power >= 0; power--) {
        resultAsArr[counter] = Math.floor(baseTenSum / (endBase ** power));
        baseTenSum -= (endBase ** power) * resultAsArr[counter];
        counter++;
    }
    // finally I need to attatch everything together into a string
    resultNumOutEl.innerHTML = arrToString(resultAsArr);
}

function findMaxPower(base, num) {
    let exponent = 0;
    while (base ** exponent <= num) {
        exponent++;
    }
    return exponent - 1;
}

function arrToString(arr) {
    let result = "";
    if (inputNumEl.value.charAt(0) === "-") {
        result = "-";
    }
    for (let index = 0; index < arr.length; index++) {
        result += numOrder[arr[index]];
    }
    return result;
}