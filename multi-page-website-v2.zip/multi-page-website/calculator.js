// Element Variables
let trapezoidEl = document.getElementById("trapezoid-btn");
let triangleEl = document.getElementById("triangle-btn");
let rectangleEl = document.getElementById("rectangle-btn");
let circleEl = document.getElementById("circle-btn");
let pentagonEl = document.getElementById("pentagon-btn");
let calculateEl = document.getElementById("calculate");
let inputOneName = document.getElementById("side1-label");
let inputTwoName = document.getElementById("side2-label");
let inputThreeName = document.getElementById("side3-label");
let inputOne = document.getElementById("side1-number");
let inputTwo = document.getElementById("side2-number");
let inputThree = document.getElementById("side3-number");
let outputMessageEl = document.getElementById("result");
let shapeResultEl = document.getElementById("shape-result");

// Global Variables
let currentShape = trapezoidEl;
let result;

// Event Listeners
trapezoidEl.addEventListener("click", selectTrapezoid);
triangleEl.addEventListener("click", selectTriangle);
rectangleEl.addEventListener("click", selectRectangle);
circleEl.addEventListener("click", selectCircle);
pentagonEl.addEventListener("click", selectPentagon);
calculateEl.addEventListener("click", compute);

// Shape selection functions: these keep track of the currently selected HTML element for use in the calculator, and also change the names of the inputs to match the selected shape. 
function selectTrapezoid() {
    selectShape(trapezoidEl, "Base length: ", "Top length: ", "Height: ");
}

function selectTriangle() {
    selectShape(triangleEl, "Base length: ", "Height: ", "none");
}

function selectRectangle() {
    selectShape(rectangleEl, "Height: ", "Width: ", "none");
}

function selectCircle() {
    selectShape(circleEl, "Radius: ", "none", "none");
}

function selectPentagon() {
    selectShape(pentagonEl, "Side length: ", "none", "none");
}

function selectShape(shape, iOneN, iTwoN, iThreeN) {
    currentShape.classList.remove("selected");
    currentShape = shape;
    shape.classList.add("selected");
    inputOneName.innerHTML = iOneN;
    inputTwoName.innerHTML = iTwoN;
    inputThreeName.innerHTML = iThreeN;
    if (iTwoN === "none") {
        inputTwo.classList.add("greyout");
        inputTwoName.classList.add("greyout");
    } else {
        inputTwo.classList.remove("greyout");
        inputTwoName.classList.remove("greyout");
    }
    if (iThreeN === "none") {
        inputThree.classList.add("greyout");
        inputThreeName.classList.add("greyout");
    } else {
        inputThree.classList.remove("greyout");
        inputThreeName.classList.remove("greyout");
    }
}

// The actual calculator - it's funny how little of the program this takes up! 
function compute() {
    if (currentShape === trapezoidEl) {
        result = 0.5 * (+inputOne.value + +inputTwo.value) * +inputThree.value;
        shapeResultEl.innerHTML = "trapezoid";
    } else if (currentShape === triangleEl) {
        result = 0.5 * +inputOne.value * +inputTwo.value;
        shapeResultEl.innerHTML = "triangle";
    } else if (currentShape === rectangleEl) {
        result = +inputOne.value * +inputTwo.value;
        shapeResultEl.innerHTML = "rectangle";
    } else if (currentShape === circleEl) {
        result = Math.PI * ((+inputOne.value) ** 2);
        result = "roughly " + result;
        shapeResultEl.innerHTML = "circle";
    } else if (currentShape === pentagonEl) {
        result = 0.25 * Math.sqrt(5 * (5 + 2 * Math.sqrt(5))) * (+inputOne.value) ** 2;
        result = "roughly " + result;
        shapeResultEl.innerHTML = "regular pentagon";
    }
    outputMessageEl.innerHTML = result;
}